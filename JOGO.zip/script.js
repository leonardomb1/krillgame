var char1 = document.getElementById("char1");
var char2 = document.getElementById("char2");
function jump(){
    if(character.classList != "animate"){
        char1.classList.add("animate");
    }
    setTimeout(function(){
        character.classList.remove("animate");
    }, 500);
var checkDead = setInterval(function(){}, 10);
}
    